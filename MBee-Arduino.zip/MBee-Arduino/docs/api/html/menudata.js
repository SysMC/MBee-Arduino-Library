var menudata={children:[
{text:"Титульная страница",url:"index.html"},
{text:"Классы",url:"annotated.html",children:[
{text:"Классы",url:"annotated.html"},
{text:"Алфавитный указатель классов",url:"classes.html"},
{text:"Иерархия классов",url:"hierarchy.html"},
{text:"Члены классов",url:"functions.html",children:[
{text:"Указатель",url:"functions.html",children:[
{text:"a",url:"functions.html#index_a"},
{text:"b",url:"functions.html#index_b"},
{text:"c",url:"functions.html#index_c"},
{text:"f",url:"functions.html#index_f"},
{text:"g",url:"functions.html#index_g"},
{text:"i",url:"functions.html#index_i"},
{text:"m",url:"functions.html#index_m"},
{text:"r",url:"functions.html#index_r"},
{text:"s",url:"functions.html#index_s"},
{text:"t",url:"functions.html#index_t"},
{text:"w",url:"functions.html#index_w"}]},
{text:"Функции",url:"functions_func.html",children:[
{text:"a",url:"functions_func.html#index_a"},
{text:"b",url:"functions_func.html#index_b"},
{text:"c",url:"functions_func.html#index_c"},
{text:"f",url:"functions_func.html#index_f"},
{text:"g",url:"functions_func.html#index_g"},
{text:"i",url:"functions_func.html#index_i"},
{text:"m",url:"functions_func.html#index_m"},
{text:"r",url:"functions_func.html#index_r"},
{text:"s",url:"functions_func.html#index_s"},
{text:"t",url:"functions_func.html#index_t"},
{text:"w",url:"functions_func.html#index_w"}]}]}]},
{text:"Файлы",url:"files.html",children:[
{text:"Файлы",url:"files.html"}]}]}
